import { checkForName } from './js/nameChecker'
import { handleSubmit } from './js/formHandler'

//Ref:https://knowledge.udacity.com/questions/534915
import './styles/base.css'
import './styles/footer.css'
import './styles/form.css'
import './styles/header.css'
import './styles/resets.css'

console.log(checkForName);

alert("I EXIST")
console.log("CHANGE!!");

export{
    checkForName,
    handleSubmit
}
