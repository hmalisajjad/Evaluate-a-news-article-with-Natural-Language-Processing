//ref: https://knowledge.udacity.com/questions/539331
const dotenv = require('dotenv');
const fetch = require('node-fetch');
const cors = require('cors');
dotenv.config();
var path = require('path')
const express = require('express')
const mockAPIResponse = require('./mockAPI.js')
const app = express()
const API_KEY = process.env.API_KEY
//'&appid=5c44c18ab9ddbc0c5f72a28a3849c8cb';
//const apiKey = process.env.API_KEY
//from: https://www.meaningcloud.com/developer/sentiment-analysis/dev-tools/2.1, nodejs, https://www.meaningcloud.com/developer/sentiment-analysis/doc/2.1/request
//
//Dependies
const bodyParser = require('body-parser')
/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());
console.log(__dirname)
// Cors for cross origin allowance
const { url } = require('inspector');
app.use(express.static('dist'))
//for api key
console.log(`Your API key is ${process.env.API_KEY}`);
//ref: https://knowledge.udacity.com/questions/536010
app.get("/", (req, res) => res.sendFile("index.html"));
/*app.get('/', function (req, res) {
    res.sendFile('dist/index.html')
    //res.sendFile(path.resolve('src/client/views/index.html'))
})
// designates what port the app will listen to for incoming requests
//app.listen(8080, function () {
  //  console.log('Example app listening on port 8080!')
//})
*/
app.listen(8081, function () {
    console.log('Example app listening on port 8080!')
})
app.get('/test', function (req, res) {
    res.send(mockAPIResponse)
})
//we need post request and fetch data 
// get idea from https://knowledge.udacity.com/questions/533709
app.post('/test', async (req, res) => {
    const url = req.body.formText;
    const baseURL = `https://api.meaningcloud.com/sentiment-2.1?key=${API_KEY}&lang=en&url=${url}`;
    const result = await fetch(baseURL, {
        method: 'POST'
    })
    try {
        const newData = await result.json();
        console.log(newData)
        res.send(newData);
    }
    catch (error) {
        console.log("error", error);
        //approximately handle the error
    }
});

